package connection;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionString {
	static Connection con=null;
	//single connection object for whole application since we used static
	static{
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/tourism?autoReconnect=true&useSSL=false",
				"root", "root");
            System.out.println("database Connected Successfully.");
		}catch(Exception e){
				e.printStackTrace();
			}
	}
	//returns already existing connection object
	public static Connection getCon(){
		return con;
	}
}
